<?php
include "connection.php";

$value1 = $_POST['value1'];
$value2 = $_POST['value2'];
$value3 = $_POST['value3'];
$value4 = $_POST['value4'];
$value5 = $_POST['value5'];
$value6 = $_POST['value6'];
$value7 = $_POST['value7'];
$value8 = $_POST['value8'];
$value9 = $_POST['value9'];

$val1 = "{$value1}%"; // Humidity direct show
$val2 = "{$value2}%"; // Humidity direct show
$val3 = ($value3 > 1000) ? "Gas Detected! ({$value3})" : "Normal";
$val4 = ($value4 > 500) ? "Earthquake! ({$value4})" : "Normal";
$val5 = ($value5 < 500) ? "Fire Detected! ({$value5})" : "Normal";
$val6 = ($value6 < 10) ? "Lower Distance! ({$value6})" : "Normal";
$val7 = ($value7 < 1000) ? "Low Pressure! ({$value7})" : "Normal";
$val8 = ($value8 < 1200) ? "Land Slide! ({$value8})" : "Normal";
$val9 = ($value9 < 4) ? "{$value9}" : "Normal";

$a = json_encode(["value1" => $val1, "value2"=> $val2,"value3" => $val3, "value4"=> $val4,"value5" => $val5, "value6"=> $val6,"value7" => $val7, "value8"=> $val8,"value9"=> $val9]);
        file_put_contents("light.json", $a);

date_default_timezone_set('Asia/Kolkata');
$timestamp = date("Y-m-d H:i:s");

// Insert into DB
$sql = "INSERT INTO disaster_detection (value1,value2,value3,value4,value5,value6,value7,value8,value9,reading_time)
        VALUES ('$value1', '$value2', '$value3','$value4','$value5','$value6','$value7','$value8','$value9', '$timestamp')";

$result = mysqli_query($conn, $sql);

if ($result) {
    echo "<p style='color:green;'>New record created successfully</p>";
} else {
    echo "<p style='color:red;'>Values Are Not Entered</p>";
}

// ---- CONDITIONS ----
$alerts = [];  // collect alerts in array

// if ($value1 > 45) {
//     $val1 = "High Temperature!";
//     $alerts[] = $val1;
// } else {
//     $val1 = "Normal";
// }

if ($value3 > 1000) {
    $val3 = "Gas Detected!
            गैस का पता चला
            வாயு கண்டறியப்பட்டது!!";
    $alerts[] = $val3;
} else {
    $val3 = "Normal";
}

if ($value4 > 500) {
    $val4 = "Earthquake Detected!
             भूकंप का पता चला
             நிலநடுக்கம் கண்டறியப்பட்டது!!";
    $alerts[] = $val4;
} else {
    $val4 = "Normal";
}

if ($value5 < 500) {
    $val5 = "Fire Detected!
            आग का पता चला!
            தீ கண்டுபிடிக்கப்பட்டது!" ;
    $alerts[] = $val5;
} else {
    $val5 = "Normal";
}

if ($value6 < 10) {
    $val6 = "Lower Distance!
                कम दूरी
                குறைந்த தூரம்!!";
    $alerts[] = $val6;
} else {
    $val6 = "Normal";
}

if ($value7 < 1000) { 
    $val7 = "Low Pressure!
             कम दबाव
            குறைந்த அழுத்தம்";
  $alerts[] = $val7;
} else {
    $val7 = "Normal";
}

if ($value8 < 1200) {
    $val8 = "Land Slide!
             भूस्खलन
             நிலச்சரிவு!";
    $alerts[] = $val8;
} else {
    $val8 = "Normal";
}

if ($value9 < 4) {
    $val9 = "Flood Detected! 
             बाढ़ का पता चला!
             வெள்ளம் கண்டறியப்பட்டது!";
    $alerts[] = $val9;
} else {
    $val9 = "Normal";
}

// ---- UI SHOW ----
if (!empty($alerts)) {
    foreach ($alerts as $msg) {
        echo "<div style='color:red;font-size:18px;font-weight:bold;margin:10px 0;'>$msg</div>";
    }

    // ---- MAIL SEND ----
    $sql_check = "SELECT last_sent_time FROM disaster_mail ORDER BY id DESC LIMIT 1";
    $result_check = mysqli_query($conn, $sql_check);
    $row = mysqli_fetch_assoc($result_check);

    $current_time = time();
    $last_sent_time = isset($row['last_sent_time']) ? strtotime($row['last_sent_time']) : 0;

    // Prevent spamming (send only once every 30 sec)
    if (($current_time - $last_sent_time) >= 30) {
        $message = "<h2>Alert:</h2><ul>";
        foreach ($alerts as $condition) {
            $message .= "<li>$condition</li>";
        }
        $message .= "</ul>";

        include("email.php"); // your mail sending file

        $sql_update_time = "INSERT INTO disaster_mail (last_sent_time) VALUES ('$timestamp')";
        mysqli_query($conn, $sql_update_time);
    }
}

// -----------------------------------
// AUTO DELETE OLD RECORDS (keep 50)
// -----------------------------------
$sql4 = "SELECT * FROM disaster_detection";
$result4 = mysqli_query($conn, $sql4);

if (mysqli_num_rows($result4) > 50) {
    $sql51 = "DELETE FROM disaster_detection ORDER BY id ASC LIMIT 1";
    $result51 = mysqli_query($conn, $sql51);
    if ($result51) {
        echo "<p style='color:orange;'>Old record deleted successfully</p>";
    }
}
?>
