<?php
// dashboard.php
include("connection.php");

// Fetch latest row
$sql = "SELECT * FROM disaster_detection ORDER BY id DESC LIMIT 1";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

// Sensor values from DB
$value3 = isset($row["value3"]) ? $row["value3"] : 0; // Gas
$value4 = isset($row["value4"]) ? $row["value4"] : 0; // Vibration
$value5 = isset($row["value5"]) ? $row["value5"] : 0; // Flame
$value6 = isset($row["value6"]) ? $row["value6"] : 0; // Distance
$value7 = isset($row["value7"]) ? $row["value7"] : 0; // Pressure
$value8 = isset($row["value8"]) ? $row["value8"] : 0; // Soil
$reading_time = isset($row["reading_time"]) ? $row["reading_time"] : date('Y-m-d H:i:s');

// Format date-only for display
$reading_date_only = date('d-m-Y', strtotime($reading_time));

// Sensors config with status rules and future days offset
$sensors = [
    'gas' => [
        'value' => $value3,
        'display' => $value3,
        'status' => ($value3 > 1000) ? 'danger' : 'normal',
        'message' => ($value3 > 1000) ? "Gas Detected!" : "Normal",
        'icon' => 'wind',
        'future_days' => 3
    ],
    'vibration' => [
        'value' => $value4,
        'display' => $value4,
        'status' => ($value4 > 500) ? 'danger' : 'normal',
        'message' => ($value4 > 500) ? "Earthquake Detected!" : "Normal",
        'icon' => 'bounding-box-circles',
        'future_days' => 4
    ],
    'flame' => [
        'value' => $value5,
        'display' => $value5,
        'status' => ($value5 < 500) ? 'danger' : 'normal',
        'message' => ($value5 < 500) ? "Fire Detected!" : "Normal",
        'icon' => 'fire',
        'future_days' => 3
    ],
    'distance' => [
        'value' => $value6,
        'display' => $value6,
        'status' => ($value6 < 10) ? 'warning' : 'normal',
        'message' => ($value6 < 10) ? "Lower Distance!" : "Normal",
        'icon' => 'rulers',
        'future_days' => 2
    ],
    'pressure' => [
        'value' => $value7,
        'display' => $value7,
        'status' => ($value7 < 1000) ? 'warning' : 'normal',
        'message' => ($value7 < 1000) ? "Low Pressure!" : "Normal",
        'icon' => 'speedometer2',
        'future_days' => 4
    ],
    'soil' => [
        'value' => $value8,
        'display' => $value8,
        'status' => ($value8 < 1200) ? 'danger' : 'normal',
        'message' => ($value8 < 1200) ? "Landslide Risk!" : "Normal",
        'icon' => 'exclamation-triangle',
        'future_days' => 5
    ],
];

// Count active alerts
$alertCount = 0;
foreach ($sensors as $s) {
    if ($s['status'] !== 'normal') $alertCount++;
}

// Future predictions with sensor-specific offsets
$predictions = [];
foreach ($sensors as $name => $sensor) {
    if ($sensor['status'] !== 'normal') {
        $future_ts = strtotime("+" . $sensor['future_days'] . " days", strtotime($reading_time));
        $future_date_only = date('d-m-Y', $future_ts);

        switch ($name) {
            case 'gas':
                $msg = "High gas levels may occur around $future_date_only";
                break;
            case 'vibration':
                $msg = "Potential seismic activity expected on $future_date_only";
                break;
            case 'flame':
                $msg = "Fire risk alert for $future_date_only";
                break;
            case 'distance':
                $msg = "Possible obstruction detected on $future_date_only";
                break;
            case 'pressure':
                $msg = "Pressure drop warning forecasted for $future_date_only";
                break;
            case 'soil':
                $msg = "Landslide risk predicted on $future_date_only";
                break;
            default:
                $msg = "Risk predicted on $future_date_only";
        }

        $predictions[$name] = [
            'future_date' => $future_date_only,
            'prediction_msg' => $msg
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Disaster Prediction Dashboard</title>
  <meta http-equiv="refresh" content="5"> <!-- optional refresh -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body{font-family:'Segoe UI',sans-serif;background:linear-gradient(120deg,#e6f7ff,#fff7e6);padding:24px;color:#0f172a;}
    .header{background:linear-gradient(90deg,#0f172a,#3b82f6);color:#fff;padding:18px 22px;border-radius:12px;display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;box-shadow:0 10px 30px rgba(2,6,23,0.08);}
    .title{font-size:1.6rem;font-weight:700;letter-spacing:0.2px;}
    .reading-date{background: rgba(255,255,255,0.12);padding:10px 14px;border-radius:10px;font-weight:600;}
    .alert-card{border-radius:12px;padding:16px;display:flex;gap:14px;align-items:center;margin-bottom:14px;box-shadow:0 6px 18px rgba(2,6,23,0.06);}
    .alert-danger{background: linear-gradient(90deg,#ffe6e6,#ffd6d6);border-left:6px solid #ef4444;}
    .alert-warn{background: linear-gradient(90deg,#fff6e6,#fff0d6);border-left:6px solid #f59e0b;}
    .alert-icon{font-size:1.8rem;width:48px;text-align:center;}
    .alert-title{font-weight:700;margin-bottom:6px;}
    .sensor-value{font-weight:600;margin-bottom:6px;}
    .prediction-badge{display:inline-block;margin-top:8px;padding:8px 12px;border-radius:14px;background:linear-gradient(90deg,#ecfeff,#e6f7ff);font-weight:700;color:#0b5d63;box-shadow:0 6px 16px rgba(11,93,99,0.08);}
    .prediction-msg{margin-top:8px;font-weight:600;color:#064e3b;}
    .no-alerts{padding:30px;border-radius:14px;background:#ffffff;box-shadow:0 6px 20px rgba(2,6,23,0.05);text-align:center;font-weight:700;}
  </style>
</head>
<body>
  <div class="container-fluid">
    <div class="header">
      <div class="title">Disaster Prediction Dashboard</div>
      <div class="reading-date">Last reading: <?php echo htmlspecialchars($reading_date_only); ?></div>
    </div>

    <?php if ($alertCount > 0): ?>
      <h5 class="mb-3"><i class="bi bi-exclamation-circle-fill text-danger"></i> Active Alerts (<?php echo $alertCount; ?>)</h5>

      <?php foreach ($sensors as $name => $sensor): ?>
        <?php if ($sensor['status'] !== 'normal'): ?>
          <div class="alert-card <?php echo ($sensor['status']=='danger')?'alert-danger':'alert-warn'; ?>">
            <div class="alert-icon"><i class="bi bi-<?php echo $sensor['icon']; ?>"></i></div>
            <div class="flex-grow-1">
              <div class="alert-title"><?php echo ucfirst($name); ?> — <?php echo $sensor['message']; ?></div>
              <div class="sensor-value">Current: <?php echo htmlspecialchars($sensor['display']); ?></div>
              <?php if(isset($predictions[$name])): ?>
                <div class="prediction-badge"><?php echo $predictions[$name]['future_date']; ?></div>
                <div class="prediction-msg"><?php echo htmlspecialchars($predictions[$name]['prediction_msg']); ?></div>
              <?php endif; ?>
            </div>
            <div><i class="bi bi-arrow-right-circle-fill fs-3"></i></div>
          </div>
        <?php endif; ?>
      <?php endforeach; ?>

    <?php else: ?>
      <div class="no-alerts"><i class="bi bi-check-circle-fill text-success" style="font-size:28px;"></i><div style="margin-top:8px;">No active alerts — sensors are normal</div></div>
    <?php endif; ?>

  </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
