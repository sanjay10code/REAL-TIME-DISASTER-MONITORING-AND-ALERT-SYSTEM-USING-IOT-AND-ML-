<?php
include("connection.php");

// Fetch all records from the database
$sql = "SELECT * FROM disaster_detection ORDER BY id DESC";
$result = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>History | IoT Disaster Detection</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="//cdn.rawgit.com/rainabba/jquery-table2excel/1.1.0/dist/jquery.table2excel.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3f51b5;
            --accent: #4cc9f0;
            --danger: #e53935;
            --warning: #fb8c00;
            --success: #43a047;
            --bg: #f4f6fa;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg);
        }
        .header {
            background: linear-gradient(135deg, var(--primary), #5c6bc0);
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .header h3 {
            margin: 0;
        }
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
        }
        .btn-primary:hover {
            background-color: #303f9f;
            border-color: #303f9f;
        }
        .page-title {
            text-align: center;
            font-size: 2rem;
            font-weight: 700;
            margin: 2rem 0;
            position: relative;
        }
        .page-title::after {
            content: '';
            display: block;
            width: 80px;
            height: 4px;
            background: var(--accent);
            margin: 0.5rem auto 0;
            border-radius: 2px;
        }
        .card {
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.05);
            margin-bottom: 2rem;
            overflow: hidden;
        }
        .table th {
            background-color: var(--primary);
            color: white;
            font-size: 0.8rem;
            text-transform: uppercase;
        }
        .table td {
            vertical-align: middle;
        }
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: white;
        }
        .table-striped tbody tr:nth-of-type(even) {
            background-color: #f9fafc;
        }
        .table-hover tbody tr:hover {
            background-color: rgba(63, 81, 181, 0.05);
        }
        .status-badge {
            padding: 0.3rem 0.6rem;
            font-size: 0.75rem;
            font-weight: 600;
            border-radius: 999px;
        }
        .status-normal {
            background-color: rgba(67, 160, 71, 0.1);
            color: var(--success);
        }
        .status-warning {
            background-color: rgba(255, 193, 7, 0.15);
            color: var(--warning);
        }
        .status-danger {
            background-color: rgba(229, 57, 53, 0.15);
            color: var(--danger);
        }
    </style>
</head>
<body>
    <header class="header d-flex justify-content-between align-items-center">
        <h3><i class="fas fa-fire-alt me-2"></i>Disaster Detection System</h3>
        <a href="index.php" class="btn btn-light"><i class="fas fa-arrow-left"></i> Dashboard</a>
    </header>

    <div class="container py-5">
        <h2 class="page-title">Sensor Data History</h2>
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div><i class="fas fa-database me-2 text-primary"></i>All Records</div>
            <button id="dwnldBtn" class="btn btn-primary"><i class="fas fa-file-excel"></i> Export to Excel</button>
        </div>
        <div class="card">
            <div class="table-responsive">
                <table class="table table-striped table-hover" id="dataTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Temperature</th>
                            <th>Humidity</th>
                            <th>Gas</th>
                            <th>Vibration</th>
                            <th>Flame</th>
                            <th>Distance</th>
                            <th>Soil</th>
                            <th>Pressure</th>
                            <th>Disaster</th>
                            <th>Timestamp</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (mysqli_num_rows($result) > 0) {
                            $i = 1;
                            while ($row = mysqli_fetch_assoc($result)) {

$value3 = $row['value3'];
$value4 = $row['value4'];
$value5 = $row['value5'];
$value6 = $row['value6'];
$value7 = $row['value7'];
$value8 = $row['value8'];


$val3 = ($value3 > 1000) ? "Gas Detected!" : "Normal";
$val4 = ($value4 > 500) ? "Earthquake!" : "Normal";
$val5 = ($value5 < 500) ? "Fire Detected!" : "Normal";
$val6 = ($value6 < 10) ? "Lower Distance!" : "Normal";
$val7 = ($value7 < 1000) ? "Low Pressure!" : "Normal";
$val8 = ($value8 < 1200) ? "Land Slide!" : "Normal";

                                
                                
                                echo '<tr>';
                                echo '<td>' . $i++ . '</td>';
                                echo '<td>' . $row['value1'] . '&#8451;</td>';
                                echo '<td>' . $row['value2'] . '%</td>';
                                echo '<td>' . $val3 . '</td>';
                                echo '<td>' . $val4 . '</td>';
                                echo '<td>' . $val5 . '</td>';
                                echo '<td>' . $val6 . '</td>';
                                echo '<td>' . $val7 . '</td>';
                                echo '<td>' . $val8 . '</td>';
                                echo '<td>' . $row['value9'] . '</td>';
                                echo '<td>' . date('M j, Y H:i:s', strtotime($row['reading_time'])) . '</td>';
                                echo '</tr>';
                            }
                        } else {
                            echo '<tr><td colspan="11" class="text-center py-4 text-muted">No data found.</td></tr>';
                        } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            $('#dwnldBtn').click(function () {
                $("#dataTable").table2excel({
                    filename: "Disaster_Detection_Data.xls",
                    name: "SensorData"
                });
            });
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
