<?php
include("connection.php");

$sql = "SELECT * FROM disaster_detection ORDER BY id DESC LIMIT 1";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

$value1 = $row["value1"]; // Temperature
$value2 = $row["value2"]; // Humidity
$value3 = $row["value3"]; // Gas
$value4 = $row["value4"]; // Vibration
$value5 = $row["value5"]; // Flame
$value6 = $row["value6"]; // Distance
$value7 = $row["value7"]; // Pressure
$value8 = $row["value8"]; // Soil
$value9 = $row["value9"]; // Disaster
$date   = $row["reading_time"];

// ---- CONDITIONS WITH VALUES ----
$val1 = "{$value1}&#8451;"; // Humidity direct show
$val2 = "{$value2}%"; // Humidity direct show
$val3 = ($value3 > 1000) ? "Gas Detected! ({$value3})" : "Normal";
$val4 = ($value4 > 500) ? "Earthquake! ({$value4})" : "Normal";
$val5 = ($value5 < 500) ? "Fire Detected! ({$value5})" : "Normal";
$val6 = ($value6 < 10) ? "Lower Distance! ({$value6})" : "Normal";
$val7 = ($value7 < 1000) ? "Low Pressure! ({$value7})" : "Normal";
$val8 = ($value8 < 1200) ? "Land Slide! ({$value8})" : "Normal";
$val9 = ($value9 < 4) ? "{$value9}" : "Normal";
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Disaster Detection Dashboard</title>
  <meta charset="utf-8">
  <meta http-equiv="refresh" content="5">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap & Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

  <!-- Custom Style -->
  <style>
    :root {
      --primary: #0f172a;
      --secondary: #3b82f6;
      --danger: #ef4444;
      --success: #10b981;
      --bg-light: #f1f5f9;
      --glass-bg: rgba(255, 255, 255, 0.15);
      --border-glass: rgba(255, 255, 255, 0.2);
    }
    body {
      background: linear-gradient(135deg, #e0f2fe, #fef9c3);
      font-family: 'Segoe UI', sans-serif;
      padding: 20px;
      color: var(--primary);
    }
    .dashboard-header {
      background: linear-gradient(to right, var(--primary), var(--secondary));
      color: white;
      border-radius: 15px;
      padding: 25px 30px;
      margin-bottom: 30px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
      display: flex;
      justify-content: space-between;
      flex-wrap: wrap;
    }
    .dashboard-title {
      font-size: 2.2rem;
      font-weight: bold;
    }
    .last-updated {
      font-size: 0.95rem;
      font-weight: 500;
      color: #e5e7eb;
      margin-top: 10px;
    }
    .card {
      border: none;
      border-radius: 20px;
      background: var(--glass-bg);
      backdrop-filter: blur(10px);
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
      overflow: hidden;
      transition: transform 0.3s ease;
      border: 1px solid var(--border-glass);
    }
    .card:hover { transform: scale(1.03); }
    .card-header {
      background: transparent;
      color: var(--primary);
      font-weight: 600;
      font-size: 1rem;
      padding: 15px 20px;
      display: flex;
      align-items: center;
      border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    }
    .card-header i { font-size: 1.5rem; margin-right: 10px; color: var(--secondary); }
    .card-body { padding: 25px 20px; text-align: center; }
    .sensor-value { font-size: 1.1rem; font-weight: 600; }
    .card-disaster { background: linear-gradient(to right, #f43f5e, #fb7185); color: white; }
    .card-disaster .card-header i, .card-disaster .sensor-value { color: white; }
    .btn-primary {
      background-color: var(--secondary);
      border: none;
      border-radius: 12px;
      padding: 12px 20px;
      font-weight: 600;
      box-shadow: 0 6px 15px rgba(59, 130, 246, 0.3);
    }
    .btn-primary:hover { background-color: #2563eb; transform: translateY(-2px); }
  </style>
</head>
<body>
<div class="container-fluid">
  <div class="dashboard-header">
    <h1 class="dashboard-title">Disaster Detection Dashboard</h1>
  <a href="disaster_predication.php" target="">
    <h4 class="dashboard-title" style="color:white;">Disaster Prediction Page</h4>
</a>
    <div class="last-updated">Last updated: <?= date('M j, Y H:i:s', strtotime($date)) ?></div>
  </div>

  <div class="row g-4">
    <!-- Temperature -->
    <div class="col-md-6 col-lg-3"><div class="card"><div class="card-header"><i class="bi bi-thermometer-half"></i> Temperature</div><div class="card-body"><div class="sensor-value"><?= $val1 ?></div></div></div></div>
    <!-- Humidity -->
    <div class="col-md-6 col-lg-3"><div class="card"><div class="card-header"><i class="bi bi-droplet-half"></i> Humidity</div><div class="card-body"><div class="sensor-value"><?= $val2 ?></div></div></div></div>
    <!-- Gas -->
    <div class="col-md-6 col-lg-3"><div class="card"><div class="card-header"><i class="bi bi-wind"></i> Gas</div><div class="card-body"><div class="sensor-value"><?= $val3 ?></div></div></div></div>
    <!-- Vibration -->
    <div class="col-md-6 col-lg-3"><div class="card"><div class="card-header"><i class="bi bi-bounding-box-circles"></i> Vibration</div><div class="card-body"><div class="sensor-value"><?= $val4 ?></div></div></div></div>
    <!-- Flame -->
    <div class="col-md-6 col-lg-3"><div class="card"><div class="card-header"><i class="bi bi-fire"></i> Flame</div><div class="card-body"><div class="sensor-value"><?= $val5 ?></div></div></div></div>
    <!-- Distance -->
    <div class="col-md-6 col-lg-3"><div class="card"><div class="card-header"><i class="bi bi-rulers"></i> Distance</div><div class="card-body"><div class="sensor-value"><?= $val6 ?></div></div></div></div>
    <!-- Pressure -->
    <div class="col-md-6 col-lg-3"><div class="card"><div class="card-header"><i class="bi bi-speedometer2"></i> Pressure</div><div class="card-body"><div class="sensor-value"><?= $val7 ?></div></div></div></div>
    <!-- Soil -->
    <div class="col-md-6 col-lg-3"><div class="card"><div class="card-header"><i class="bi bi-exclamation-triangle"></i> Soil</div><div class="card-body"><div class="sensor-value"><?= $val8 ?></div></div></div></div>
    <!-- Disaster -->
    <div class="col-md-6 col-lg-3"><div class="card card-disaster"><div class="card-header"><i class="bi bi-exclamation-diamond-fill"></i> Disaster</div><div class="card-body"><div class="sensor-value"><?= $val9 ?></div></div></div></div>
    <!-- History Button -->
    <div class="col-md-6 col-lg-3 d-flex align-items-end"><a href="sensor_fetchdata.php" class="btn btn-primary w-100"><i class="bi bi-clock-history"></i> View History</a></div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
