<?php
include("connection.php");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$mail = new PHPMailer(true);

try {
    echo "<div style='display:none;'>";
    $mail->SMTPDebug = 2;
    $mail->isSMTP();
    $mail->Host = 'mail.iotcloud22.in';
    $mail->SMTPAuth = true;
    $mail->Username = 'mail@iotcloud22.in';
    $mail->Password = 'iotcloud22@123';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom('mail@iotcloud22.in', 'IOT Project');
    $mail->addAddress('Sanjaysureshbabu1@gmail.com');

    $mail->isHTML(true);
    $mail->Subject = 'Disaster Alert';
    $mail->Body = "
        <strong>$message</strong>
    ";

    $mail->send();
    echo "</div>";
    echo "Mail has been sent successfully!";
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

?>
